﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SnakeBlock : MonoBehaviour
{
    
	void Start()
	{

	}


	void FixedUpdate()
	{

	}
}
